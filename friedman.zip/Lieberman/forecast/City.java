package Lieberman.forecast;

public class City {
	@Override
	public String toString() {
		return "City [id=" + id + ", name=" + name + ", coord=" + coord
				+ ", country=" + country + ", population=" + population + "]";
	}
	private String id;
	private String name;
	private Coordinates coord;
	private String country;
	private String population;

}
