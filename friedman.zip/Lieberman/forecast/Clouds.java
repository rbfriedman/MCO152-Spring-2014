package Lieberman.forecast;

public class Clouds {
	private int all;

	public Clouds(int all) {
		this.all = all;
	}
}
