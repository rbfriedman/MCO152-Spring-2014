package Lieberman.forecast;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JPanel;

public class ForecastPanel extends JPanel {

	private final double PAD = 0;
	private ArrayList<Double> temps;
	private ArrayList<Date> dates;

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		int w = getWidth();
		int h = getHeight();
		// Draw ordinate.
		g2.draw(new Line2D.Double(PAD, PAD, PAD, h - PAD));

		// Draw abcissa.
		g2.draw(new Line2D.Double(PAD, h - PAD, w - PAD, h - PAD));
		double xInc = (double) (w - 2 * PAD) / (temps.size() - 1);
		double scale = (double) (h - 2 * PAD) / getMax();
		// Mark data points.
		g2.setPaint(Color.red);
		for (int i = 0; i < temps.size(); i++) {
			double x = PAD + i * xInc;
			double y = h - PAD - scale * temps.get(i);
			g2.fill(new Ellipse2D.Double(x - 2, y - 2, 4, 4));
		}
	}

	private Double getMax() {
		Double max = (double) -Integer.MAX_VALUE;
		for (int i = 0; i < temps.size(); i++) {
			if (temps.get(i) > max)
				max = temps.get(i);
		}
		return max;
	}

	// protected void paintComponent(Graphics g) {
	// super.paintComponent(g);
	// Graphics2D g2 = (Graphics2D) g;
	// g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	// RenderingHints.VALUE_ANTIALIAS_ON);
	// int w = getWidth();
	// int h = getHeight();
	// // Draw ordinate.
	// g2.draw(new Line2D.Double(PAD, PAD, PAD, h - PAD));
	// // Draw abcissa.
	// g2.draw(new Line2D.Double(PAD, h - PAD, w - PAD, h - PAD));
	// double xInc = (double) (w - 2 * PAD) / (temps.size() - 1);
	// double scale = (double) (h - 2 * PAD) / getMax();
	// // Mark data points.
	// g2.setPaint(Color.red);
	// for (int i = 0; i < temps.size(); i++) {
	// double x = PAD + i * xInc;
	// double y = h - PAD - scale * temps.get(i);
	// g2.fill(new Ellipse2D.Double(x - 2, y - 2, 4, 4));
	// }
	// }
	//
	// private double getMax() {
	// Double max = (double) -Integer.MAX_VALUE;
	// for (int i = 0; i < temps.size(); i++) {
	// if (temps.get(i) > max)
	// max = temps.get(i);
	// }
	// return max;
	// }

	// paint component
	// width/temps.getSize()
	// draw each temp (g.filledOval)

	// x and y axis
	// specify height and width
	// top is (0,0)
	// mite want to scale

	public ForecastPanel(ArrayList<Double> temps, ArrayList<Date> dates) {
		this.temps = temps;
		this.dates = dates;

	}

}
