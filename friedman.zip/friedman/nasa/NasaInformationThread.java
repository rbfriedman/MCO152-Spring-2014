package friedman.nasa;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import friedman.earthquakes.EarthquakeReportList;

public class NasaInformationThread extends Thread {
	private NasaFrame nasaFrame;
	private  String feed_url;
	private RoverCam roverCam;

	public NasaInformationThread(NasaFrame nasaFrame) {
		this.nasaFrame = nasaFrame;
		this.feed_url = "http://merpublic.s3.amazonaws.com/oss/mera/images/images_sol6.json";

	}
	public void updateUrl(String newFeed){
		this.feed_url = newFeed;
	}
	public void run() {
		try {

			URL url = new URL(feed_url);
			URLConnection connection = url.openConnection();
			InputStream in = connection.getInputStream();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(in));
			final JsonReader jsonReader = new JsonReader(reader);

			Gson gson = new Gson();
			roverCam = gson.fromJson(jsonReader, RoverCam.class);
			System.out.println("RoverCam Info has been read in\n"
					+ roverCam.toString());

			nasaFrame.loadRoverCamInfo(roverCam);
			// frame.loadEarthquakeInfo(earthquakeReportList);
			// window.refresh(quakes);
		} catch (MalformedURLException m) {
			m.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
