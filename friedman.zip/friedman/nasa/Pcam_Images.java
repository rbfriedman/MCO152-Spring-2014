package friedman.nasa;

public class Pcam_Images extends Images{

	@Override
	public String toString() {
		return super.toString();
	}

}
