package friedman.nasa;

import java.util.Arrays;

public class Images {
	private Image[] images;

	public Image[] getImages() {
		return images;
	}

	public void setImages(Image[] images) {
		this.images = images;
	}

	@Override
	public String toString() {
		return  Arrays.toString(images) ;
	}
}
