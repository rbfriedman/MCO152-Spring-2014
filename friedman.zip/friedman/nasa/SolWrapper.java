package friedman.nasa;

import java.util.Arrays;

public class SolWrapper {
	private Sol[] sols;

	public Sol[] getSols() {
		return sols;
	}

	@Override
	public String toString() {
		return "SolWrapper [sols=" + Arrays.toString(sols) + "]";
	}

}
