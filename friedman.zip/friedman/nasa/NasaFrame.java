package friedman.nasa;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;

/*
 * For your final you will build an application to browse the images of Sol6.
 The title of the window must have the mission name, Sol number and number of images.
 The left hand side must be a JList. The JList must have a scroll bar
 The right hand side displays the image.
 When you select an image on the left, the image must then be displayed on the right.

 */
public class NasaFrame extends JFrame {
	private JList<String> jlMissions;
	private JScrollPane scrollPane;
	private JLabel jlbImage;
	
	private DownloadNasaPageThread webPageThread;
	private NasaInformationThread thread;
	private Map<String, String> mapOfRover;
	private Map<String,String> mapFromCombo;
	private JComboBox<String> jcbSol;
	
	public NasaFrame() {
		
		this.jlMissions = new JList<String>();
		this.jlbImage = new JLabel();
		this.jcbSol = new JComboBox<String>();
		scrollPane = new JScrollPane(this.jlMissions);
		
		this.jcbSol.addActionListener(new JComboListener());
		add(this.jcbSol,BorderLayout.NORTH);
		add(scrollPane, BorderLayout.WEST);
		add(this.jlbImage,BorderLayout.CENTER);
		this.jlMissions.addMouseListener(new SelectionListener());
		
		webPageThread = new DownloadNasaPageThread(this);
		/*Did not have time to implement*/
		//webPageThread.start();
		thread = new NasaInformationThread(this);
		thread.start();
		// general JFrame settings
		this.setSize(600, 600);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	

	public void loadRoverCamInfo(RoverCam roverCam) {
		
		this.setTitle(roverCam.getMissionInfo());
		
		int sizeOfList = roverCam.getNumImages();
		mapOfRover = new HashMap<String,String>();
		int j=0;
		for(int i=0; i <roverCam.getFcam_images().length;i++){
			for(Image img:roverCam.getFcam_images()[i].getImages() ){
				
				mapOfRover.put(img.toString(), img.getUrl());
			}
		}
		for(int i=0; i <roverCam.getNcam_images().length;i++){
			for(Image img:roverCam.getNcam_images()[i].getImages() ){	
				mapOfRover.put(img.toString(), img.getUrl());
			}
		}
		for(int i=0; i <roverCam.getRcam_images().length;i++){
			for(Image img:roverCam.getRcam_images()[i].getImages() ){
				
				mapOfRover.put(img.toString(), img.getUrl());
			}
		}
		for(int i=0; i <roverCam.getPcam_images().length;i++){
			for(Image img:roverCam.getPcam_images()[i].getImages() ){
				
				mapOfRover.put(img.toString(), img.getUrl());
			}
		}
		
		System.out.println(mapOfRover.size());
		String[] arr = new String[sizeOfList];
		int i=0;
		for(String s:mapOfRover.keySet()){
			arr[i++] = s;
		}
		this.jlMissions.setListData(arr);

		this.setVisible(true);
		
	}
	
	
	public void loadWebPageInfo(SolWrapper solWrapper) {
		// TODO Auto-generated method stub
		mapFromCombo = new HashMap<String,String>();
		for(Sol s:solWrapper.getSols()){
			mapFromCombo.put(s.getSol(), s.getUrl());
			this.jcbSol.addItem(s.getSol());
		}
		
	}
	
	public static void main(String[] args) {
		NasaFrame nf = new NasaFrame();
		nf.setVisible(true);

	}
	private class SelectionListener implements MouseListener {
	    public void mouseClicked(MouseEvent e) {
	        if (e.getClickCount() == 1) {


	           String selectedItem = (String) jlMissions.getSelectedValue();
	           DownloadImageThread thread = new DownloadImageThread(jlbImage,mapOfRover.get(selectedItem));
	           thread.start();
	           
	           
	         }
	    }

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}

	private class JComboListener  implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
	        JComboBox cb = (JComboBox)e.getSource();
	        String sol = (String)cb.getSelectedItem();
	        updateSol(sol);
	    }

		private void updateSol(String sol) {
			// TODO Auto-generated method stub
			thread.updateUrl(mapFromCombo.get(sol));
			//repaint();
		}
	   
	}

}
