package friedman.nasa;

public class Fcam_Images extends Images {
	@Override
	public String toString() {
		return super.toString();
	}
}
