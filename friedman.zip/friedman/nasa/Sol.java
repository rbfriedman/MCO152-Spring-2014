package friedman.nasa;

public class Sol {
	private String sol;
	private String url;
	public String getSol() {
		return sol;
	}
	public String getUrl() {
		return url;
	}
}
