package friedman.nasa;

import java.util.Arrays;

public class ImageWrapper {
	private Image[] images;

	public Image[] getImages() {
		return images;
	}


	@Override
	public String toString() {
		return Arrays.toString(images);

	}
}
