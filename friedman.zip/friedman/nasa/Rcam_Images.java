package friedman.nasa;

public class Rcam_Images extends Images{
	@Override
	public String toString() {
		return super.toString();
	}
}
