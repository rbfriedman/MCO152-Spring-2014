package friedman.nasa;

public class Image {
	private String imageid;
	private String url;
	@Override
	public String toString() {
		return imageid ;
	}
	
	public String getUrl(){
		return url;
	}
	
}
