package friedman.nasa;

public class Ncam_Images extends Images {
	@Override
	public String toString() {
		return super.toString();
	}
}
