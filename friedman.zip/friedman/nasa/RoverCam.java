package friedman.nasa;

import java.util.Arrays;

public class RoverCam {
	private String mission;
	private String sol;
	private Pcam_Images[] pcam_images;
	private Ncam_Images[] ncam_images;
	private Fcam_Images[] fcam_images;
	private Rcam_Images[] rcam_images;

	@Override
	public String toString() {
		return "RoverCam [mission=" + mission + ", sol=" + sol
				+ ", pcam_images=" + Arrays.toString(pcam_images)
				+ ", ncam_images=" + Arrays.toString(ncam_images)
				+ ", fcam_images=" + Arrays.toString(fcam_images)
				+ ", rcam_images=" + Arrays.toString(rcam_images) + "]";
	}

	public int getNumImages() {
		int num =0;
		for(int i=0; i <pcam_images.length;i++){
			for(Image img:pcam_images[i].getImages() ){
				
				num+=1;
			}
		}
		for(int i=0; i <ncam_images.length;i++){
			for(Image img:ncam_images[i].getImages() ){
				
				num+=1;
			}
		}
		for(int i=0; i <rcam_images.length;i++){
			for(Image img:rcam_images[i].getImages() ){
				
				num+=1;
			}
		}
		for(int i=0; i <fcam_images.length;i++){
			for(Image img:fcam_images[i].getImages() ){
				
				num+=1;
			}
		}
	
		
		return num;
	}
	
	

	public Pcam_Images[] getPcam_images() {
		return pcam_images;
	}

	public void setPcam_images(Pcam_Images[] pcam_images) {
		this.pcam_images = pcam_images;
	}

	public Ncam_Images[] getNcam_images() {
		return ncam_images;
	}

	public void setNcam_images(Ncam_Images[] ncam_images) {
		this.ncam_images = ncam_images;
	}

	public Fcam_Images[] getFcam_images() {
		return fcam_images;
	}

	public void setFcam_images(Fcam_Images[] fcam_images) {
		this.fcam_images = fcam_images;
	}

	public Rcam_Images[] getRcam_images() {
		return rcam_images;
	}

	public void setRcam_images(Rcam_Images[] rcam_images) {
		this.rcam_images = rcam_images;
	}

	public String getMissionInfo() {
		// TODO Auto-generated method stub
		return new StringBuilder().append(this.mission).append(" ")
				.append("Sol(").append(this.sol).append(") ")
				.append(this.getNumImages()).toString();
	}
}
