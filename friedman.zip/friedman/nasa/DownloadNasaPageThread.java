package friedman.nasa;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

public class DownloadNasaPageThread extends Thread {
	private NasaFrame nasaFrame;
	private static final String FEED_URL = "https://merpublic.s3.amazonaws.com/oss/mera/images/image_manifest.json";
	private SolWrapper solWrapper;

	public DownloadNasaPageThread(NasaFrame nasaFrame) {
		this.nasaFrame = nasaFrame;

	}
	
	public void run() {
		try {

			URL url = new URL(FEED_URL);
			URLConnection connection = url.openConnection();
			InputStream in = connection.getInputStream();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(in));
			final JsonReader jsonReader = new JsonReader(reader);

			Gson gson = new Gson();
			solWrapper = gson.fromJson(jsonReader, SolWrapper.class);
			System.out.println("SolWrapper Info has been read in\n"
					+ solWrapper.toString());

			nasaFrame.loadWebPageInfo(solWrapper);
			// frame.loadEarthquakeInfo(earthquakeReportList);
			// window.refresh(quakes);
		} catch (MalformedURLException m) {
			m.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
