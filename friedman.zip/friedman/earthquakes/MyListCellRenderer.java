package friedman.earthquakes;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;


	class MyListCellRenderer extends Component implements ListCellRenderer {

		/**
		 * 
		 */
		private static final long serialVersionUID = -5507811426864727444L;

		@Override
		public Component getListCellRendererComponent(JList jlist, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			// TODO Auto-generated method stub
			int val = Integer.valueOf((String) value);
			System.out.println(val);
				 switch(val) {
				 case 1 :
					 this.setBackground(new Color(25,25,112));
					 break;
				 case 2:
					 this.setBackground(Color.BLUE);
					 break;
				 case 3:
					 this.setBackground(new Color(65,164,35));
					 break;
				 case 4:
					 this.setBackground(new Color(69,168,182));
					 break;
				 case 5:
					 this.setBackground(new Color(85,242,106));
					 break;
				 case 6:
					 this.setBackground(Color.YELLOW);
					 break;
				 case 7:
					 this.setBackground(Color.ORANGE);
					 break;
				 case 8:
					 this.setBackground(new Color(226,123,97));
					 break;
				 case 9:
					 this.setBackground(Color.red);
					 break;
				 case 10:
					 this.setBackground(new Color(183,24,12));
					 break;
					 
				 }
			   
		        
		      

		        return this;
		}

}
