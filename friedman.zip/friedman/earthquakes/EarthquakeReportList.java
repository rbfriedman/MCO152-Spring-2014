package friedman.earthquakes;

import java.util.ArrayList;

public class EarthquakeReportList extends ArrayList<EarthquakeReport>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3572608651919723301L;

}
