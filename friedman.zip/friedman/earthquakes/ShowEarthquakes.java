package friedman.earthquakes;

public class ShowEarthquakes {
	public static void main(String[] args){
		EarthquakeReportFrame frame = new EarthquakeReportFrame();
		
	}
}
