package friedman.conditions;

public class Conditions {
	private Coordinates coord;
	private Sys sys;
	private Weather[] weather;
	private String base;
	private Main main;
	private Wind wind;
	private Clouds clouds;
	private String dt;
	private String id;
	private String name;
	private int cod;
}
