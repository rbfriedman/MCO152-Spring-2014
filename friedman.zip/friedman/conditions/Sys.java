package friedman.conditions;

public class Sys {
	private String message;
	private String country;
	private String dex;
	/**
	 * @param args
	 */


}
