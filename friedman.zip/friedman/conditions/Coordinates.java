package friedman.conditions;

public class Coordinates {
	private double lon;
	private double lat;

}
