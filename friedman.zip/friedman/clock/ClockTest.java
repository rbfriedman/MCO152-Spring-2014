package friedman.clock;

public class ClockTest {

	public ClockTest() {
		// TODO Auto-generated constructor stub
	}

}
