package friedman.flicker;

import com.google.gson.annotations.SerializedName;

public class Media {
	@SerializedName("m")
	private String imageLink;

	public String getImageLink() {
		// TODO Auto-generated method stub
		return imageLink;
	}
}
