package friedman.flicker;

/**
 * The class that represents the json feed from Flicker
 */
public class FlickerFeed {
	private Photos items;

	public Photos getItems() {
		// TODO Auto-generated method stub
		return items;
	}

}
