package friedman.flicker;

public class Photo {
	private Media media;

	public Media getMedia() {
		// TODO Auto-generated method stub
		return media;
	}
}
