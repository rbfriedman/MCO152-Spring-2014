package friedman.flicker;

import java.util.ArrayList;

public class Photos extends ArrayList<Photo> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -754649629904204034L;

}
