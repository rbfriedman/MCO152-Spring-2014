package friedman.ufo;

import java.util.ArrayList;

public class Sightings extends ArrayList<Sighting>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 457072191123478710L;

}
