package friedman.tictactoe;

public enum Symbol {
	X,O;
}
