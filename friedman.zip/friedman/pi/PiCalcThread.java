package friedman.pi;

import javax.swing.JTextArea;

public class PiCalcThread extends Thread {
private JTextArea area;
	public PiCalcThread(JTextArea area) {
		// TODO Auto-generated constructor stub
		super();
		this.area = area;
	}
	public void run(){
		
	

}	
}
