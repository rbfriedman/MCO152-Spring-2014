package friedman.weather;

public class RunWeatherGraph {
	public static void main(String[] args){
		WeeklyWeatherFrame wwfLine = new WeeklyWeatherFrame();
		wwfLine.setVisible(true);
	}
}
