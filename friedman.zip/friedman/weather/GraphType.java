package friedman.weather;

public enum GraphType {
	BAR,LINE;
}
